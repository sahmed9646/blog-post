<?php 
class Category{
   private $db;
   public function __construct(){
      $this->db = new Database;
   }

   public function getCategories(){
      $this->db->query("SELECT * FROM categories");
      $result = $this->db->resultSet();
      return $result;
   }

   public function getCategoryById($id){
      $this->db->query("SELECT * FROM categories WHERE id = :id ");
      $this->db->bind(':id', $id);
      return $this->db->single();
   }

   public function totalCategories(){
      $this->db->query("SELECT * FROM categories");
      $this->db->resultSet();
      if ($this->db->rowCount()) {
         return $this->db->rowCount();
      }
   }
}
