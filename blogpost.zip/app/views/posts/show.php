<?php require APPROOT.'/views/inc/header.php'; ?>
<a href="<?php echo URLROOT; ?>/posts" class="btn btn-light"><i class="fa fa-backward"></i> Go Back</a>
<br>

<h1><?php echo $data['post']->title; ?><small class="bg-light h6 ml-4 pt-1 pl-3 pr-3 pb-1"><?php echo $data['category']->catName?></small></h1>

<div class="bg-secondary p-2 mb-3 text-white">
   written by <?php echo $data['user']->name; ?> on <?php echo $data['post']->created_at; ?>
</div>
<p class="lead p-3"><?php echo $data['post']->body; ?></p>
<?php if($data['post']->user_id == $_SESSION['user-id']): ?>
<hr>
   <a href="<?php echo URLROOT; ?>/posts/edit/<?php echo $data['post']->id; ?>" class="btn btn-dark">Edit</a>

   <form action="<?php echo URLROOT; ?>/posts/delete/<?php echo $data['post']->id; ?>" method="post" class="pull-right">
      <input type="submit" value="Delete" class="btn btn-danger">
   </form>
<?php endif; ?>
<?php require APPROOT.'/views/inc/footer.php'; ?>