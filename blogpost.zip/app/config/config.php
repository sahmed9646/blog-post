<?php

// Database Params
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db_blogpostMVC');


// define APPROOT
define('APPROOT', dirname(dirname(__FILE__)));

// define URL ROOT
define('URLROOT', 'http://localhost/blogpost-mvc');

// define SITE NAME
define('SITENAME', 'Blog-Post');